﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTheAionProject.Models;

namespace WpfTheAionProject.DataLayer
{
    /// <summary>
    /// static class to store the game data set
    /// </summary>
    public static class GameData
    {
        public static Player PlayerData()
        {
            return new Player()
            {
                Id = 1,
                Name = "Dostrya",
                Age = 43,
                Race = Character.RaceType.Cybran,
                Health = 100,
                Lives = 3,
                LocationId = 0,
                Threat = 0
            };
        }

        public static List<string> InitialMessages()
        {
            return new List<string>()
            {
                "\tYou have been hired by <your faction> ",
                "\tYour goal is to convince all of the factions to ally against the Seraphim Threat"
            };
        }
    }
}
