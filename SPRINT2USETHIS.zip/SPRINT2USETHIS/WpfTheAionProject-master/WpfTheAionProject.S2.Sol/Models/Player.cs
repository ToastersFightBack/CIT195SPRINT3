﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Data;

namespace WpfTheAionProject.Models
{
    /// <summary>
    /// player class
    /// </summary>
    public class Player : Character
    {
        #region ENUMS


        #endregion

        #region FIELDS

        private int _lives;
        private int _health;
        private int _threatlevel2;
        private int _factionacceptence;

        private ObservableCollection<GameItem> _inventory;
        private ObservableCollection<GameItem> _treasure;

        public int FactionAcceptence
        {
            get { return _factionacceptence; }
            set { _factionacceptence = value; }
        }


        private List<Location> _locationsVisited;

        #endregion

        #region PROPERTIES
        public void UpdateInventoryCategories()
        {
            
           
            Treasure.Clear();
            

            foreach (var gameItem in _inventory)
            {
                
                if (gameItem is Treasure) Treasure.Add(gameItem);
                
            }
        }
        public void AddGameItemToInventory(GameItem selectedGameItem)
        {
            if (selectedGameItem != null)
            {
                _inventory.Add(selectedGameItem);
            }
        }

        public void RemoveGameItemFromInventory(GameItem selectedGameItem)
        {
            if (selectedGameItem != null)
            {
                _inventory.Remove(selectedGameItem);
            }
        }

        public int Lives
        {
            get { return _lives; }
            set
            {
                _lives = value;
                OnPropertyChanged(nameof(Lives));
            }
        }

        

        public int Health
        {
            get { return _health; }
            set
            {
                _health = value;
                OnPropertyChanged(nameof(Health));
            }
        }

        public int ThreatLevelModifyer
        {
            get { return _threatlevel2; }
            set
            {
                _threatlevel2 = value;
                OnPropertyChanged(nameof(ThreatLevelModifyer));
            }
        }

        public List<Location> LocationsVisited
        {
            get { return _locationsVisited; }
            set { _locationsVisited = value; }
        }
        public ObservableCollection<GameItem> Inventory
        {
            get { return _inventory; }
            set { _inventory = value; }
        }
        public ObservableCollection<GameItem> Treasure
        {
            get { return _treasure; }
            set { _treasure = value; }
        }


        #endregion

        #region CONSTRUCTORS

        public Player()
        {
            _locationsVisited = new List<Location>();
            _treasure = new ObservableCollection<GameItem>();
        }

        
        #endregion

        #region METHODS

        public bool HasVisited(Location location)
        {
            return _locationsVisited.Contains(location);
        }

        /// <summary>
        /// override the default greeting in the Character class to include the job title
        /// set the proper article based on the job title
        /// </summary>
        /// <returns>default greeting</returns>
        public override string DefaultGreeting()
        {
            string article = "a";

            List<string> vowels = new List<string>() { "A", "E", "I", "O", "U" };

           

            return $"Hello, my name is {_name} and I am {article}  for the xd xd.";
        }

        #endregion

        #region EVENTS



        #endregion

    }
}
